# VSZipperApp
A Visual Studio extension for fast and easy project zipping excluding unnecessary obj and bin directories.

## How to use:
Right click on the project or solution you want to Zip and select the "Zip Project" or "Zip Solution" option.
A folder containing all your zip files will be automatically created within your projects directory
(this can be changed in the "Zip Project Settings" option in the project tab).
You may change the directories/files to exclude from your zip in the settings.

## How to install:
As of now this isnt available through the Extensions tab in Visual Studio (will come soon). To use this app you must clone it in Visual Studio and run the app.
